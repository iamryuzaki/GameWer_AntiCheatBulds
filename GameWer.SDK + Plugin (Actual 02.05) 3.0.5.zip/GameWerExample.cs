﻿// Reference: GameWer.SDK

using System;
using GameWer.SDK;
using Oxide.Core.Plugins;
using UnityEngine;
using System.Collections.Generic;

namespace Oxide.Plugins
{
    [Info("GameWerExample", "TheRyuzaki", "3.0.3")]
    public class GameWerExample : RustPlugin
    {
	    public const bool SettingsCheckVPN = true;
		public const bool SettingsNeedGameWerFromLicens = false;
        public const string SettingsLicensKey = "licensKey";
		public const string SettingsScreenshotDirectory = "/server/Server/Screenshots/";
		
        public GameObject BaseFrameObject { get; private set; }
		private Dictionary<ulong, bool> ListPlayersAuthed = new Dictionary<ulong, bool>();
	    private Dictionary<ulong, Oxide.Plugins.Timer> ListTimerFromPlayers = new Dictionary<ulong, Timer>();

        [HookMethod("OnServerInitialized")]
        void OnServerInitialized()
        {            
			Debug.Log($"[GameWer]: OnServerInitialized");
            this.BaseFrameObject = new GameObject();
            this.BaseFrameObject.AddComponent<FrameObject>();
			
            GameWer.SDK.Interface.NeedKickPlayer = OnNeedKickPlayer;
			GameWer.SDK.Interface.NetworkStatusChange = OnNetworkStatusChange;
			GameWer.SDK.Interface.ReceivedMachineID = OnReceivedMachineID;
			GameWer.SDK.Interface.ReceivedScreenshot = OnReceivedScreenshot;
			GameWer.SDK.Interface.ScreenshotPath = SettingsScreenshotDirectory;
            GameWer.SDK.Interface.Initialization(SettingsLicensKey, ConVar.Server.hostname); 
        }
		
		[HookMethod("OnPlayerDisconnected")]
		void OnPlayerDisconnected(BasePlayer player, string reason)
		{
			GameWer.SDK.Interface.Logout(player.Connection.userid);
			ListPlayersAuthed[player.userID] = false;
		}
		
		[HookMethod("OnPlayerInit")]
		void OnPlayerInit(BasePlayer player)
		{
			RunAuthPlayer(player);
		}
		
		[HookMethod("Unload")]
		void Unload()
		{
			UnityEngine.GameObject.Destroy(this.BaseFrameObject);
			GameWer.SDK.Interface.Shutdown();
		}
		
		void OnReceivedMachineID(ulong steamid, string machineID) {
			// NEED USE  =  GameWer.SDK.Interface.GetMachineID(steamid);
		}
		
		
		void OnReceivedScreenshot(ulong steamid, string path) {
			Debug.Log($"[GameWer]: Taked screen path [{path}] from " + steamid);
		}
		
		void OnNetworkStatusChange(bool status) {
			Puts("[GameWer]: NetStatusChange: " + status);
			if(status == true) {
				for(int i = 0; i < BasePlayer.activePlayerList.Count; ++i) {
					RunAuthPlayer(BasePlayer.activePlayerList[i]);
				}
			} else
				ListPlayersAuthed.Clear(); 
		}
		
		void OnNeedKickPlayer(ulong steamid, string reason) {
			BasePlayer player = BasePlayer.FindByID(steamid);
			if (reason == "anticheat-offline")
            {
                player?.Kick("[GameWer]: Запустите Античит GameWer что бы зайти. Скачать: https://vk.com/allowerd");
            } else
				player?.Kick("[GameWer]: " + reason);
		}
		
		void RunAuthPlayer(BasePlayer player)
        {
            try
            {
                int appID = GameWer.SDK.Interface.GetAppID(player.Connection.token);
                if (appID == 480 || SettingsNeedGameWerFromLicens)
                {
                    ListPlayersAuthed[player.userID] = true;
	                if (SettingsCheckVPN == true)
						GameWer.SDK.Interface.AuthPlayer(player.userID, player.Connection.ipaddress);
	                else
		                GameWer.SDK.Interface.AuthPlayer(player.userID);
	                
	                if (ListTimerFromPlayers.ContainsKey(player.userID))
		                ListTimerFromPlayers[player.userID].Destroy();
	                ListTimerFromPlayers[player.userID] = timer.Once(60f, () =>
	                {
		                if (player.IsConnected)
			                GetScreenshotFromTimer(player);
	                });
                    return;
                }
            }
            catch (Exception ex)
            {
                
            }
            ListPlayersAuthed[player.userID] = false;
        }

	    private void GetScreenshotFromTimer(BasePlayer player)
	    {
		    if (player.IsConnected)
		    {
			    GameWer.SDK.Interface.GetScreenshot(player.userID);
			    ListTimerFromPlayers[player.userID] = timer.Once(900f, () => GetScreenshotFromTimer(player));
		    }
	    }
		
		[ConsoleCommand("gw.screen")]
        void ScreenCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Args == null || arg.Args.Length < 1 || arg.Args[0].Length != 17)
            {
                Puts("Need use gw.screen {STEAMID}");
                return;
            }
            Debug.Log("You request from steamid: " + arg.Args[0]);

            ulong steamid = ulong.Parse(arg.Args[0]);
			if (ListPlayersAuthed.ContainsKey(steamid) && ListPlayersAuthed[steamid]) {
				GameWer.SDK.Interface.GetScreenshot(steamid);
			} else
				Debug.Log("Player steamid: " + arg.Args[0] + " - dont authed to GameWer from you server!");
		}


        class FrameObject : MonoBehaviour
        {
            private void FixedUpdate()
            {
                GameWer.SDK.Interface.Cycle();
            }
        }
    }
}