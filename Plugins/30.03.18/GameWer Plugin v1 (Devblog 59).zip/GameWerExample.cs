﻿// Reference: GameWer.SDK

using System;
using System.Collections.Generic;
using GameWer.SDK;
using Oxide.Core.Plugins;
using UnityEngine;

namespace Oxide.Plugins
{
    [Info("GameWerExample", "TheRyuzaki", "0.0.0")]
    public class GameWerExample : RustPlugin
    {
        public static GameWerExample Instance { get; private set; }

        public GameWer.SDK.Interface BaseInterface { get; private set; }
        public GameObject BaseFrameObject { get; private set; }
        
        private Queue<ulong> m_listPoolScreenshotsH = new Queue<ulong>();
        private Queue<ulong> m_listPoolScreenshotsL = new Queue<ulong>();
        private Queue<ulong> m_listPoolGetProcesses = new Queue<ulong>();
        private Queue<ulong> m_listPoolGetModules = new Queue<ulong>();

        [HookMethod("OnServerInitialized")]
        void OnServerInitialized()
        {
            Instance = this;
            
            this.BaseFrameObject = new GameObject();
            this.BaseFrameObject.AddComponent<FrameObject>();
            
            this.BaseInterface = new Interface();
            this.BaseInterface.OnNeedKickPlayer = OnNeedKickPlayer;
            this.BaseInterface.OnNetworkStatusChangeEvent = OnNetworkStatusChangeEvent;
            this.BaseInterface.OnOutputEvent = OnOutputEvent;
            this.BaseInterface.OnReceivedMachineID = OnReceivedMachineId;
            this.BaseInterface.OnReceivedProcessList = OnReceivedProcessList;
            this.BaseInterface.OnReceivedProcessModules = OnReceivedProcessModules;
            this.BaseInterface.OnReceivedScreen = OnReceivedScreen;
            this.BaseInterface.Initialization("licensKey", server.hostname);
            this.BaseInterface.ScreenshotPath = "/server/Server/Screenshots/";

            timer.Repeat(10.5f, 0, OnTakePoolScreenshot);
            timer.Repeat(1.5f, 0, OnTakePoolGetInformationUser);
        }

        private void OnTakePoolScreenshot()
        {
            if (m_listPoolScreenshotsH.Count != 0)
            {
                ulong steamid = this.m_listPoolScreenshotsH.Dequeue();
                this.BaseInterface.GetScreenshot(steamid);
                return;
            }
            if (m_listPoolScreenshotsL.Count != 0)
            {
                ulong steamid = this.m_listPoolScreenshotsL.Dequeue();
                this.BaseInterface.GetScreenshot(steamid);
                return;
            }
        }

        private void OnTakePoolGetInformationUser()
        {
            if (m_listPoolGetProcesses.Count != 0)
            {
                ulong steamid = this.m_listPoolGetProcesses.Dequeue();
                this.BaseInterface.GetProcessList(steamid);
                return;
            }
            if (m_listPoolGetModules.Count != 0)
            {
                ulong steamid = this.m_listPoolGetModules.Dequeue();
                this.BaseInterface.GetProcessModules(steamid);
                return;
            }
        }

        private void OnReceivedScreen(ulong steamid, string screenshot)
        {
            Debug.Log($"[GameWer][Result]: Player [{steamid}] take screenshot: " + screenshot);
        }

        private void OnReceivedProcessModules(ulong steamid, string modules)
        {
            Debug.Log($"[GameWer][Result]: Player [{steamid}] have modules: " + modules);
        }

        private void OnReceivedProcessList(ulong steamid, string processes)
        {
            Debug.Log($"[GameWer][Result]: Player [{steamid}] have processes: " + processes);
        }

        private void OnReceivedMachineId(ulong steamid, string machineid)
        {
            Debug.Log($"[GameWer][Result]: Player [{steamid}] have machineid: " + machineid);
        }

        #region [GameWer] [Events]
        
        private void OnOutputEvent(string s)
        {
            Debug.Log("[GameWer][Output]: " + s);
        }

        private void OnNetworkStatusChangeEvent(bool b)
        {
            Debug.Log("[GameWer][NetworkStatus]: " + b);
            
            if (b == true)
            {
                for (var i = 0; i < BasePlayer.activePlayerList.Count; i++)
                    this.BaseInterface.AuthPlayer(BasePlayer.activePlayerList[i].userID);
            }
        }
        
        void OnNeedKickPlayer(ulong steamid, string s)
        {
            BasePlayer player = BasePlayer.FindByID(steamid);
            Debug.Log($"[GameWer][Kick]: [{steamid} / {player?.displayName}] from reasone: " + s);
            player?.Kick("[GameWer]: " + s);
        }
        
        #endregion

        [HookMethod("Unload")]
        void Unload()
        {
            this.BaseInterface.Shutdown();
            GameObject.Destroy(this.BaseFrameObject);
        }

        [HookMethod("OnPlayerDisconnected")]
        void OnPlayerDisconnected(BasePlayer player, string reason)
        {
            this.BaseInterface.LogoutPlayer(player.userID);
        }

        [HookMethod("OnPlayerInit")]
        void OnPlayerInit(BasePlayer player)
        {
            this.BaseInterface.AuthPlayer(player.userID);
            timer.Once(60, () =>
            {
                if (player.IsConnected())
                {
                    if (this.m_listPoolScreenshotsL.Contains(player.userID) == false)
                    {
                        this.m_listPoolScreenshotsL.Enqueue(player.userID);
                    }
                }
            });
        }

        [ConsoleCommand("gw.screen")]
        void ScreenCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Args == null || arg.Args.Length < 1)
            {
                Puts("Need use gw.screen {STEAMID}");
                return;
            }
            Debug.Log("You request from steamid: " + arg.Args[0]);

            ulong steamid = ulong.Parse(arg.Args[0]);
            if (this.m_listPoolScreenshotsH.Contains(steamid) == false)
                this.m_listPoolScreenshotsH.Enqueue(steamid);
        }

        [ConsoleCommand("gw.getprocesses")]
        void ProcessesCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Args == null || arg.Args.Length < 1)
            {
                Puts("Need use gw.getprocesses {STEAMID}");
                return;
            }
            Debug.Log("You request from steamid: " + arg.Args[0]);
            ulong steamid = ulong.Parse(arg.Args[0]);
            if (this.m_listPoolGetProcesses.Contains(steamid) == false)
                this.m_listPoolGetProcesses.Enqueue(steamid);
        }

        [ConsoleCommand("gw.getmodules")]
        void ModulesCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Args == null || arg.Args.Length < 1)
            {
                Puts("Need use gw.getmodules {STEAMID}");
                return;
            }
            Debug.Log("You request from steamid: " + arg.Args[0]);
            ulong steamid = ulong.Parse(arg.Args[0]);
            if (this.m_listPoolGetModules.Contains(steamid) == false)
                this.m_listPoolGetModules.Enqueue(steamid);
        }

        [ConsoleCommand("gw.gethwid")]
        void HWIDCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Args == null || arg.Args.Length < 1)
            {
                Puts("Need use gw.gethwid {STEAMID}");
                return;
            }
            Debug.Log("You request from steamid: " + arg.Args[0]);
            this.BaseInterface.GetMachineID(ulong.Parse(arg.Args[0]));
        }

        class FrameObject : MonoBehaviour
        {
            private void FixedUpdate()
            {
                Instance.BaseInterface?.Cycle();
            }
        }
    }
}